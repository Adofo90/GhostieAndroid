# Ghostie Android — online-build ready

This is a native Android project for the Ghostie floating companion. It is prepared so you can build an installable APK in the cloud without installing Android Studio.

## Easiest: GitHub Actions (recommended)

1. Create a free GitHub account if you do not already have one.
2. Create a **new empty repository**.
3. Upload the **contents** of this folder to the repository. The `.github/workflows/build-apk.yml` file must be present.
4. Open the repository's **Actions** tab.
5. Select **Build Ghostie APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run and download the **Ghostie-debug-apk** artifact.
9. Extract the downloaded artifact if necessary; install `app-debug.apk` on your Android phone.

The workflow installs JDK 17 and Gradle 8.7 in the cloud, then builds `assembleDebug`. No Android Studio is required on your computer.

## Codemagic alternative

This repository also contains `codemagic.yaml`. Codemagic supports native Android projects and can produce an APK artifact. Connect this GitHub repository in Codemagic, choose the Android/native workflow, and start a build.

## Phone permissions

After installing Ghostie, open it and grant **Display over other apps**. Android may also ask for notification/foreground-service permission depending on the phone and Android version. These permissions are required for a persistent floating overlay on modern Android versions.

## Notes

- The debug APK is suitable for direct installation/testing.
- For Google Play release, create and protect a signing keystore and use a release build.
- Do not put an OpenAI API key into the source code or a public repository. Enter it inside the app instead.
