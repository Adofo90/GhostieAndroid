package com.ghostie.pet

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

object ChatEngine {
    private val basic = listOf(
        Regex("hi|hello|hey", RegexOption.IGNORE_CASE) to "Hi! I'm here with you 💜",
        Regex("nice to meet", RegexOption.IGNORE_CASE) to "Nice to meet you too! I'll keep you company.",
        Regex("how are you", RegexOption.IGNORE_CASE) to "I'm happy to be here. How are you doing?",
        Regex("tired|sleepy", RegexOption.IGNORE_CASE) to "A tiny break might help. Stretch a little and breathe.",
        Regex("water|thirst", RegexOption.IGNORE_CASE) to "Water check! A few sips would be lovely 💧",
        Regex("stressed|stress", RegexOption.IGNORE_CASE) to "Take one slow breath with me. You don't have to rush.",
        Regex("break|stretch", RegexOption.IGNORE_CASE) to "Good idea. Stand up, stretch, then come back when you're ready."
    )
    fun offline(text:String):String = basic.firstOrNull{it.first.containsMatchIn(text)}?.second ?: "I'm listening 💜 Tell me what's on your mind."
    suspend fun openAi(key:String, history:List<Pair<String,String>>, text:String):String = withContext(Dispatchers.IO) {
        val url=URL("https://api.openai.com/v1/responses"); val c=url.openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.setRequestProperty("Authorization","Bearer $key"); c.setRequestProperty("Content-Type","application/json"); c.doOutput=true
        val input=JSONArray(); history.takeLast(8).forEach{(role,msg)-> input.put(JSONObject().put("role",role).put("content",msg))}
        input.put(JSONObject().put("role","user").put("content",text))
        val body=JSONObject().put("model","gpt-4.1-mini").put("instructions",Personality.TEXT).put("input",input)
        c.outputStream.use{it.write(body.toString().toByteArray())}
        val raw=(if(c.responseCode in 200..299)c.inputStream else c.errorStream).bufferedReader().readText()
        if(c.responseCode !in 200..299) return@withContext "I couldn't reach AI mode right now. I'm still here 💜"
        val o=JSONObject(raw); o.optString("output_text").ifBlank { "I'm here with you 💜" }
    }
}
