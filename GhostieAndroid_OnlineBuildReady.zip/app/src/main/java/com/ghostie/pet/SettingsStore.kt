package com.ghostie.pet

import android.content.Context

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("ghostie", Context.MODE_PRIVATE)
    var enabled: Boolean get()=p.getBoolean("enabled",true); set(v)=p.edit().putBoolean("enabled",v).apply()
    var visitMinutes: Int get()=p.getInt("visit",5); set(v)=p.edit().putInt("visit",v).apply()
    var waterMinutes: Int get()=p.getInt("water",30); set(v)=p.edit().putInt("water",v).apply()
    var checkins: Boolean get()=p.getBoolean("checkins",true); set(v)=p.edit().putBoolean("checkins",v).apply()
    var sound: Boolean get()=p.getBoolean("sound",false); set(v)=p.edit().putBoolean("sound",v).apply()
    var animSpeed: Float get()=p.getFloat("speed",1f); set(v)=p.edit().putFloat("speed",v).apply()
    var petSize: Int get()=p.getInt("size",260); set(v)=p.edit().putInt("size",v).apply()
    var ai: Boolean get()=p.getBoolean("ai",false); set(v)=p.edit().putBoolean("ai",v).apply()
    private val secure=CryptoStore(ctx)
    var key: String get()=secure.read(); set(v)=secure.save(v)
    var alwaysTop: Boolean get()=p.getBoolean("top",true); set(v)=p.edit().putBoolean("top",v).apply()
    var quietUntil: Long get()=p.getLong("quiet",0L); set(v)=p.edit().putLong("quiet",v).apply()
    var x: Int get()=p.getInt("x",-1); set(v)=p.edit().putInt("x",v).apply()
    var y: Int get()=p.getInt("y",-1); set(v)=p.edit().putInt("y",v).apply()
    fun resetPosition(){ p.edit().remove("x").remove("y").apply() }
}
