package com.ghostie.pet

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.animation.*
import android.widget.*
import kotlin.math.roundToInt

class PetOverlayService: Service(){
    private lateinit var wm:WindowManager; private lateinit var pet:ImageView; private lateinit var bubble:TextView; private lateinit var button:ImageView
    private lateinit var ps:WindowManager.LayoutParams; private lateinit var bs:WindowManager.LayoutParams; private val h=Handler(Looper.getMainLooper()); private lateinit var s:SettingsStore
    private val messages=listOf("Hi, how are you doing?","Hi, checking in.","Hi, need a break?","Hi, want some water? 💧","Hi, quick stretch?","Hi, water check.","Hi, still doing okay?")
    override fun onCreate(){super.onCreate();s=SettingsStore(this);wm=getSystemService(WINDOW_SERVICE) as WindowManager; startForeground(7,foregroundNotice()); create(); schedule()}
    private fun foregroundNotice(): Notification {
        val channelId="ghostie_service"
        if(Build.VERSION.SDK_INT>=26){val ch=NotificationChannel(channelId,"Ghostie service",NotificationManager.IMPORTANCE_LOW);ch.setShowBadge(false);getSystemService(NotificationManager::class.java).createNotificationChannel(ch)}
        return Notification.Builder(this,channelId).setSmallIcon(R.drawable.ghost_pet).setContentTitle("Ghostie is nearby").setContentText("Floating companion is running").setOngoing(true).build()
    }
    private fun type():Int=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun create(){
        if(!Settings.canDrawOverlays(this))return
        pet=ImageView(this).apply{setImageResource(com.ghostie.pet.R.drawable.ghost_pet);scaleType=ImageView.ScaleType.FIT_CENTER;setOnClickListener{openChat()}}
        val size=s.petSize; ps=WindowManager.LayoutParams(size,size,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,android.graphics.PixelFormat.TRANSLUCENT); ps.gravity=Gravity.TOP or Gravity.START; ps.x=if(s.x>=0)s.x else 40; ps.y=if(s.y>=0)s.y else getScreenH()-size-80; wm.addView(pet,ps); animateIdle()
        bs=WindowManager.LayoutParams(72,72,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,android.graphics.PixelFormat.TRANSLUCENT);
        bs.gravity=Gravity.TOP or Gravity.START; bs.x=10; bs.y=getScreenH()/2
        button=ImageView(this).apply{setImageResource(R.drawable.ghost_pet);scaleType=ImageView.ScaleType.CENTER_INSIDE;setPadding(12,12,12,12);background=roundBg();setOnClickListener{summon()};setOnTouchListener(Drag(bs))}
        wm.addView(button,bs)
    }
    private fun roundBg()=ColorDrawable(Color.TRANSPARENT)
    private fun getScreenH()=resources.displayMetrics.heightPixels
    private fun animateIdle(){pet.animate().translationY(10f).setDuration((900/s.animSpeed).roundToInt().toLong()).setInterpolator(SineInterpolator()).withEndAction{pet.animate().translationY(0f).setDuration((900/s.animSpeed).roundToInt().toLong()).withEndAction{animateIdle()}.start()}.start();h.postDelayed({blink()},3000)}
    private fun blink(){pet.alpha=.15f;h.postDelayed({pet.alpha=1f},120);h.postDelayed({blink()},4000+(0..4000).random())}
    private fun schedule(){h.postDelayed({if(s.enabled && System.currentTimeMillis()>s.quietUntil && s.checkins)summon();schedule()},s.visitMinutes*60_000L)}
    fun summon(){if(!::pet.isInitialized)return; pet.animate().translationX(0f).alpha(1f).setDuration(500).start();showBubble(messages.random());h.postDelayed({leave()},(12_000L..30_000L).random())}
    private fun leave(){pet.animate().translationX(-resources.displayMetrics.widthPixels.toFloat()).alpha(0f).setDuration(700).withEndAction{pet.translationX=0f}.start();bubble?.let{try{wm.removeView(it)}catch(_:Exception){}}}
    
    private fun openChat(){
        if(::bubble.isInitialized)try{wm.removeView(bubble)}catch(_:Exception){}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,14,14,14);background=BubbleBg()}
        val history=TextView(this).apply{text="Ghostie: Hi! 💜\n\n";textSize=14f;setTextColor(Color.rgb(55,35,75))}; box.addView(history,LinearLayout.LayoutParams(300,180))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; val input=EditText(this).apply{hint="Say something…";singleLine=true}; val send=Button(this).apply{text="➤"}; row.addView(input,LinearLayout.LayoutParams(0,60,1f));row.addView(send,LinearLayout.LayoutParams(60,60));box.addView(row)
        val close=Button(this).apply{text="Close";setOnClickListener{try{wm.removeView(box)}catch(_:Exception){}}};box.addView(close)
        send.setOnClickListener{val q=input.text.toString().trim();if(q.isNotEmpty()){history.text=history.text.toString()+"You: $q\n";input.text.clear(); if(s.ai && s.key.isNotBlank()){kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch{val a=ChatEngine.openAi(s.key,emptyList(),q);history.text=history.text.toString()+"Ghostie: $a\n\n"}}else{val a=ChatEngine.offline(q);history.text=history.text.toString()+"Ghostie: $a\n\n"}}}
        val lp=WindowManager.LayoutParams(330,300,type(),WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,android.graphics.PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP or Gravity.START;lp.x=maxOf(10,ps.x-20);lp.y=maxOf(50,ps.y-320);wm.addView(box,lp)
    }
    private fun showBubble(msg:String){if(::bubble.isInitialized)try{wm.removeView(bubble)}catch(_:Exception){};bubble=TextView(this).apply{text=msg;setTextColor(Color.rgb(55,35,75));textSize=15f;setPadding(24,16,24,16);background=BubbleBg()};val lp=WindowManager.LayoutParams(260,WindowManager.LayoutParams.WRAP_CONTENT,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,android.graphics.PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP or Gravity.START;lp.x=ps.x+ps.width-20;lp.y=maxOf(80,ps.y+50);wm.addView(bubble,lp)}
    override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{when(i?.action){"SUMMON"->summon();"RESET"->{s.resetPosition();stopSelf();startService(Intent(this,PetOverlayService::class.java))}};return START_STICKY}
    override fun onDestroy(){h.removeCallbacksAndMessages(null);try{wm.removeView(pet);wm.removeView(button);if(::bubble.isInitialized)wm.removeView(bubble)}catch(_:Exception){};super.onDestroy()}
    override fun onBind(i:Intent?)=null
    inner class Drag(private val lp:WindowManager.LayoutParams):View.OnTouchListener{var sx=0f;var sy=0f;var ox=0;var oy=0;override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.action){0->{sx=e.rawX;sy=e.rawY;ox=lp.x;oy=lp.y};2->{lp.x=(ox+e.rawX-sx).toInt().coerceIn(0,resources.displayMetrics.widthPixels-lp.width);lp.y=(oy+e.rawY-sy).toInt().coerceIn(0,getScreenH()-lp.height);wm.updateViewLayout(v,lp)};1->{s.x=lp.x;s.y=lp.y}};return true}}
    class SineInterpolator:Interpolator{override fun getInterpolation(x:Float)=((Math.sin((x-.5)*Math.PI)+1)/2).toFloat()}
    class BubbleBg:android.graphics.drawable.GradientDrawable(){init{setColor(Color.WHITE);cornerRadius=28f;setStroke(2,Color.rgb(190,150,235))}}
}
