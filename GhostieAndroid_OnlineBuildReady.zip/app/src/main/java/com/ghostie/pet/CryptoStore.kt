package com.ghostie.pet

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class CryptoStore(private val ctx: Context){
    private val alias="GhostieApiKey"
    private fun key():SecretKey{
        val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
        if(ks.containsAlias(alias)) return (ks.getEntry(alias,null) as java.security.KeyStore.SecretKeyEntry).secretKey
        val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return kg.generateKey()
    }
    fun save(value:String){
        if(value.isBlank()){ctx.getSharedPreferences("ghostie_secure",0).edit().remove("key").apply();return}
        val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());val blob=c.iv+ c.doFinal(value.toByteArray())
        ctx.getSharedPreferences("ghostie_secure",0).edit().putString("key",Base64.getEncoder().encodeToString(blob)).apply()
    }
    fun read():String{val b64=ctx.getSharedPreferences("ghostie_secure",0).getString("key",null)?:return "";return try{val b=Base64.getDecoder().decode(b64);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,b.copyOfRange(0,12)));String(c.doFinal(b.copyOfRange(12,b.size)))}catch(_:Exception){""}}
}
