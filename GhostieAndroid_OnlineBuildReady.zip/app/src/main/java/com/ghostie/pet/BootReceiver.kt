package com.ghostie.pet
import android.content.*
import android.os.Build
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){if(i.action==Intent.ACTION_BOOT_COMPLETED && SettingsStore(c).enabled){val x=Intent(c,PetOverlayService::class.java);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(x) else c.startService(x)}}}
