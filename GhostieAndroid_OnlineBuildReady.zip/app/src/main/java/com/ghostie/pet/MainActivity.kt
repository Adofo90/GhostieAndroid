package com.ghostie.pet

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity: AppCompatActivity(){
    private lateinit var s:SettingsStore
    override fun onCreate(b:Bundle?){super.onCreate(b); s=SettingsStore(this); build()}
    private fun build(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28); gravity=Gravity.CENTER_HORIZONTAL}
        val title=TextView(this).apply{text="👻 Ghostie"; textSize=30f; gravity=Gravity.CENTER}
        root.addView(title, LinearLayout.LayoutParams(-1,-2))
        val info=TextView(this).apply{text="Your tiny floating companion"; gravity=Gravity.CENTER; setPadding(0,0,0,20)}; root.addView(info)
        fun sw(label:String, checked:Boolean, on:(Boolean)->Unit){val x=Switch(this).apply{text=label; isChecked=checked; setOnCheckedChangeListener{_,v->on(v)}}; root.addView(x,LinearLayout.LayoutParams(-1,-2))}
        sw("Enable pet",s.enabled){s.enabled=it}
        sw("Check-ins",s.checkins){s.checkins=it}
        sw("AI chat",s.ai){s.ai=it}
        sw("Always on top",s.alwaysTop){s.alwaysTop=it}
        sw("Sound",s.sound){s.sound=it}
        val visits=Spinner(this); visits.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("5 min","10 min","15 min","30 min","1 hour")); visits.setSelection(listOf(5,10,15,30,60).indexOf(s.visitMinutes).coerceAtLeast(0)); visits.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:android.widget.AdapterView<*>?){}; override fun onItemSelected(p:android.widget.AdapterView<*>?,v:Int,id:Long){s.visitMinutes=listOf(5,10,15,30,60)[v]}}; root.addView(TextView(this).apply{text="Visit frequency"}); root.addView(visits)
        val water=Spinner(this); water.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("15 min","30 min","1 hour","2 hours")); water.setSelection(listOf(15,30,60,120).indexOf(s.waterMinutes).coerceAtLeast(0)); water.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:android.widget.AdapterView<*>?){}; override fun onItemSelected(p:android.widget.AdapterView<*>?,v:Int,id:Long){s.waterMinutes=listOf(15,30,60,120)[v]}}; root.addView(TextView(this).apply{text="Water reminder"}); root.addView(water)
        val key=EditText(this).apply{hint="OpenAI API key (optional)"; setText(s.key); inputType=129}; root.addView(key)
        val save=Button(this).apply{text="Save & Start Pet"; setOnClickListener{s.key=key.text.toString(); if(!Settings.canDrawOverlays(this@MainActivity)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))} else startForegroundService(Intent(this@MainActivity,PetOverlayService::class.java)); Toast.makeText(this@MainActivity,"Ghostie is ready 👻",Toast.LENGTH_SHORT).show()}}; root.addView(save)
        val summon=Button(this).apply{text="Summon now"; setOnClickListener{startService(Intent(this@MainActivity,PetOverlayService::class.java).setAction("SUMMON"))}}; root.addView(summon)
        val quiet30=Button(this).apply{text="Pause 30 minutes";setOnClickListener{s.quietUntil=System.currentTimeMillis()+30*60_000L;Toast.makeText(this@MainActivity,"Quiet for 30 minutes",Toast.LENGTH_SHORT).show()}};root.addView(quiet30)
        val quiet60=Button(this).apply{text="Pause 1 hour";setOnClickListener{s.quietUntil=System.currentTimeMillis()+60*60_000L;Toast.makeText(this@MainActivity,"Quiet for 1 hour",Toast.LENGTH_SHORT).show()}};root.addView(quiet60)
        val tomorrow=Button(this).apply{text="Pause until tomorrow";setOnClickListener{s.quietUntil=java.time.LocalDate.now().plusDays(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();Toast.makeText(this@MainActivity,"Quiet until tomorrow",Toast.LENGTH_SHORT).show()}};root.addView(tomorrow)
        val resume=Button(this).apply{text="Resume";setOnClickListener{s.quietUntil=0;Toast.makeText(this@MainActivity,"Ghostie resumed",Toast.LENGTH_SHORT).show()}};root.addView(resume)
        val reset=Button(this).apply{text="Bring Ghostie on screen"; setOnClickListener{s.resetPosition(); startService(Intent(this@MainActivity,PetOverlayService::class.java).setAction("RESET"))}}; root.addView(reset)
        setContentView(ScrollView(this).apply{addView(root)})
    }
}
